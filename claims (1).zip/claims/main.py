import csv, sys
from os.path import exists

def syntaxMessage():
    print("""
        syntax: main.py [FILENAME] [OUTPUT FILE NAME]
        example:
                main.py test_data.csv result
    """)
    exit(1)

if len(sys.argv) != 3:
    syntaxMessage()
    
if not exists(sys.argv[1]):
    print("[!] File Not Found!\nTry adding the CSV Data file in Current Folder.")
    syntaxMessage()

filename = sys.argv[1]
output_file = sys.argv[2]

fields = []
tmp = []
rows = []
products = []

with open(filename,'r') as csv_data_file:
    csvreader = csv.reader(csv_data_file, skipinitialspace = False, delimiter=',')
    tmp = next(csvreader)
    for row in csvreader:
        temp = []
        for i in row:
            temp.append(i.strip())
        rows.append(temp)

for i in tmp:
    fields.append(i.strip())

for row in rows:
    row[1] = int(row[1])
    row[2] = int(row[2])
    row[3] = float(row[3])
    if row[0] not in products:
        products.append(row[0])

data = {}
data[fields[0]] = {}

for product in products:
    data[fields[0]][product] = {
        fields[1]:{},
    }


for product in products:
    for row in rows:
        if row[0] == product:
            data[fields[0]][product][fields[1]][row[1]] = {
                fields[2]:[],
                fields[3]:[]
            }

for product in products:
    for row in rows:
        if row[0] == product:
            data[fields[0]][product][fields[1]][row[1]][fields[2]].append(row[2])
            data[fields[0]][product][fields[1]][row[1]][fields[3]].append(row[3])

result_data = {}


#print(data)
for i in data[fields[0]]:
    result_data[i] = {}
    #print("---Products---")
    for j in data[fields[0]][i][fields[1]]:
        result_data[i][j] = {}
        #print(j)
        dev_years = data[fields[0]][i][fields[1]][j][fields[2]]
        incr_value = data[fields[0]][i][fields[1]][j][fields[3]]
        #print(dev_years)
        #print(incr_value)
        try:
            index = 0
            while True:
                if dev_years[index+1] != dev_years[index]+1:
                    dev_years.insert(index+1, dev_years[index]+1)
                    incr_value.insert(index+1, 0)

                index+=1
                if dev_years[-1] - dev_years[index] == 0:
                    break
            
            result_data[i][j][fields[2]] = dev_years
            result_data[i][j][fields[3]] = incr_value
        except IndexError:
            result_data[i][j][fields[2]] = dev_years
            result_data[i][j][fields[3]] = incr_value

#print(result_data)

final_data = {}
origin_year = 100000
count = 0

for product in result_data:
    #print("---PRODUCT---")
    final_data[product] = []
    for origin in result_data[product]:
        #print("---ORIGIN---")
        if origin < origin_year:
            origin_year = origin
            count = len(result_data[product][origin][fields[2]])
        temp = 0
        for incr in result_data[product][origin][fields[3]]:
            _sum = incr+temp
            temp = _sum
            final_data[product].append(_sum)

#print(final_data)
max_len = 0
for product in final_data:
    if len(final_data[product]) > max_len:
        max_len = len(final_data[product])

for product in final_data:
    temp = [0] * max_len
    temp[-len(final_data[product]):] = final_data[product]
    final_data[product] = temp

#print(origin_year,count)
#print(final_data)

content = []
header = content.append([origin_year, count])
for product in final_data:
    temp = [product]
    for i in final_data[product]:
        temp.append(i)
    content.append(temp)

print(content)

with open(output_file+".csv","w") as f:
    writer = csv.writer(f)
    for row in content:
        writer.writerow(row)
